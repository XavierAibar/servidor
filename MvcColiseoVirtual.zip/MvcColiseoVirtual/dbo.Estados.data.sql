﻿SET IDENTITY_INSERT [dbo].[Estados] ON
INSERT INTO [dbo].[Estados] ([Id], [Descripcion]) VALUES (1, N'Pendiente')
INSERT INTO [dbo].[Estados] ([Id], [Descripcion]) VALUES (2, N'Confirmado')
SET IDENTITY_INSERT [dbo].[Estados] OFF
